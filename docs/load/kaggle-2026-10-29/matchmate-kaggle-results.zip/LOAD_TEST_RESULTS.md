# Kết quả tải

Số đo lấy từ artifacts của từng lượt; latency tính bằng ms.
Nghiệm thu Kaggle CPU dùng các lượt environment=kaggle trong metadata.

| Profile | Môi trường | Users | Đủ 60s | RPS | p50 | p95 | p99 | 5xx | BUSY | 409 | Invariant |
|---|---|---:|---|---:|---:|---:|---:|---:|---:|---:|---|
| read | kaggle | 10 | True | 6.5890838617708365 | 11 | 14 | 34 | 0 | 0 | 0 | {'over_capacity': 0, 'accepted_overlap': 0, 'active_in_cancelled': 0, 'open_without_host': 0} |
| read | kaggle | 50 | True | 32.909821048229254 | 13 | 32 | 54 | 0 | 0 | 0 | {'over_capacity': 0, 'accepted_overlap': 0, 'active_in_cancelled': 0, 'open_without_host': 0} |
| read | kaggle | 100 | True | 65.24770154685349 | 24 | 100 | 180 | 0 | 0 | 0 | {'over_capacity': 0, 'accepted_overlap': 0, 'active_in_cancelled': 0, 'open_without_host': 0} |
| lifecycle | kaggle | 10 | True | 28.79370477232206 | 31 | 120 | 270 | 0 | 0 | 0 | {'over_capacity': 0, 'accepted_overlap': 0, 'active_in_cancelled': 0, 'open_without_host': 0} |
| lifecycle | kaggle | 50 | False | n/a | n/a | n/a | n/a | n/a | n/a | n/a | {'over_capacity': 0, 'accepted_overlap': 0, 'active_in_cancelled': 0, 'open_without_host': 0} |
| lifecycle | kaggle | 100 | False | n/a | n/a | n/a | n/a | n/a | n/a | n/a | {'over_capacity': 0, 'accepted_overlap': 0, 'active_in_cancelled': 0, 'open_without_host': 0} |
